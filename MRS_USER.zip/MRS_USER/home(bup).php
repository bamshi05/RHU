<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MRSUSER</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style type="text/css">
  :root
{
  --text: "Select past medical condition(s)";
}
.multiple_select
{
  height: 38px;
  width: 100%;
  overflow: hidden;
  -webkit-appearance: menulist;
  position: relative;
}
.multiple_select::before
{
  content: var(--text);
  display: block;
}
.multiple_select_active
{
  height: 150px;
    overflow-y: scroll;
}
.multiple_select option
{
  display: none;
    height: 18px;
  background-color: white;
}
.multiple_select_active option
{
  display: block;
}

.multiple_select option::before {
  content: "\2610";
}
.multiple_select option:checked::before {
  content: "\2611";
}
.multiple_selectmed
{
  --text: "Select medicine(s) taken(in the last 3 mos.)";
  height: 38px;
  width: 100%;
  overflow: hidden;
  -webkit-appearance: menulist;
  position: relative;
}
.multiple_selectmed::before
{
  content: var(--text);
  display: block;
}
.multiple_select_activemed
{
  height: 150px;
    overflow-y: scroll;
}
.multiple_selectmed option
{
  display: none;
    height: 18px;
  background-color: white;
}
.multiple_select_activemed option
{
  display: block;
}

.multiple_selectmed option::before {
  content: "\2610";
}
.multiple_selectmed option:checked::before {
  content: "\2611";
}

.dropdownform
{
  overflow: hidden;
  -webkit-appearance: menulist;
  position: relative;
}

</style>

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="index.php">MRUSER</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Appointment Form</a></li>
          <li><a class="nav-link scrollto " href="#portfolio">News & Events</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li class="dropdown"><a href="#"><span>Account Options</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#" onclick="log_out()">Sign-out</a></li>
            </ul>
          </li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <div class="header-social-links d-flex align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="container text-center text-md-left" data-aos="fade-up">
      <h1>Welcome to <span>Buenavista RHU Medical Record System</span></h1>
      <h2>Book your doctors appointment now!!!</h2>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= What We Do Section ======= -->
    <section id="what-we-do" class="what-we-do">
      <div class="container">

        <div class="section-title">
          <h2>What We Do</h2>
          <p>We take care of your health, because your health is our wealth</p>
        </div>
      </div>
    </section><!-- End What We Do Section -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-6">
            <img src="assets/img/about.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <h3>About Us</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Appointment Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Appointment Form</h2>
          <p>Please fill all necessary information</p>
        <!-- ======= Appointment Form Section ======= -->
    <section class="contact section-bg">
      <div class="container">
        <div class="row mt-5 justify-content-center">
          <div class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Name" required>
                </div>
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="address" placeholder="Address" required>
                </div>
                <div class="col-md-6 form-group">
                  <input type="text" name="phone" class="form-control" id="phone" placeholder="Phone no.">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="number" class="form-control" name="age" id="age" placeholder="Age" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                        <select class="form-control dropdownform" id="gender" required>
                          <option value="Gender">Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="text" class="form-control" name="height" id="height" placeholder="Height">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="text" class="form-control" name="weight" id="weight" placeholder="Weight">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                        <select class="form-control dropdownform" id="civilstatus" required>
                          <option value="Civil Status">Civil Status</option>
                          <option value="Single">Single</option>
                          <option value="Married">Married</option>
                          <option value="Widowed">Widowed</option>
                          <option value="Legally Separated">Legally Separated</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="text" class="form-control" name="parentname" id="parentname" placeholder="Parent/Guardian/Spouse Name">
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                        <select class="form-control multiple_select" id="medicalcondition" multiple required>
                          <option value="No past medical history!">No past medical history!</option>
                          <option value="Fever">Fever</option>
                          <option value="Asthma">Asthma</option>
                          <option value="Pneumonia">Pneumonia</option>
                          <option value="Allergies">Allergies</option>
                          <option value="Conjunctivitis">Conjunctivitis</option>
                          <option value="Diarrhea">Diarrhea</option>
                          <option value="Headaches">Headaches</option>
                          <option value="Mononucleosis">Mononucleosis</option>
                          <option value="Stomach Aches">Stomach Aches</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                        <select class="form-control multiple_selectmed" id="medication" multiple required>
                          <option value="No prescription yet!">Not taken any medicine!</option>
                          <option value="Ibuprofen">Ibuprofen</option>
                          <option value="Paracetamol">Paracetamol</option>
                          <option value="Albuterol">Albuterol</option>
                          <option value="Antibiotics">Antibiotics</option>
                          <option value="Cetirizine">Cetirizine</option>
                          <option value="Loratadine">Loratadine</option>
                          <option value="Loperamide">Loperamide</option>
                          <option value="Triptans">Triptans</option>
                          <option value="Omeprazole">Omeprazole</option>
                        </select>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                        <span class="form-label">Appointment Date</span>
                        <input type="date" class="form-control" name="appointdate" id="date" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                        <span class="form-label">Time of Appointment</span>
                        <input type="Time" class="form-control" name="appointtime" id="time" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="additional" id="additional" rows="5" placeholder="Additional information of the patient if there's any..."></textarea>
              </div>
              <div class="my-3">
                <div></div>
                <div></div>
                <div></div>
              </div>
              <div class="text-center"><button type="submit" id="setbutton" onclick="add_data()">Set Appointment</button></div>
              <div class="my-3">
                <div></div>
              </div>
              <div class="text-center"><button type="submit" id="updatebutton" onclick="update()" style="background: #28a745;">Update Appointment</button></div>
              <div class="my-3">
                <div></div>
              </div>
              <div class="text-center"><button type="submit" id="editbutton" onclick="edit()" style="background: #28a745;">Edit Appointment</button></div>
              <div class="my-3">
                <div></div>
              </div>
              <div class="text-center"><button type="submit" id="cancelbutton" onclick="cancel()" style="background: #dc3545;">Cancel Appointment</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Appointment Form Section -->
    </div>
      </div>
    </section><!-- End Appointment Section -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->

<script>
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAcA8u0hL4KKhGjDRJEnEm1jhHUAfcTsaE",
    authDomain: "tsisdb.firebaseapp.com",
    databaseURL: "https://tsisdb.firebaseio.com",
    projectId: "tsisdb",
    storageBucket: "tsisdb.appspot.com",
    messagingSenderId: "117101059158",
    appId: "1:117101059158:web:0676e4596c5ed5dcfd2ff7"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
</script>
<script>
var appointmentkey, newvalue, key;
  var Loggedusername = localStorage.getItem("loggedusername");
  firebase.database().ref("useraccounts").orderByChild("regnusername").equalTo(Loggedusername).once("value").then(function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    key = childSnapshot.key;
    firebase.database().ref("useraccounts/" + key + "/regnemail").once("value").then(function(snapshot) {
        newvalue = snapshot.val(); 
  document.getElementById("email").value = newvalue;
  document.getElementById("email").readOnly = true;
          firebase.database().ref("appointment").orderByChild("email").equalTo(newvalue).once("value",snap => {
                            if (snap.exists()) {
                                    firebase.database().ref("appointment")
                                    .orderByChild("email")
                                    .equalTo(newvalue)
                                    .once("value")
                                    .then(function(snapshot) {
                                      snapshot.forEach(function(childSnapshot) {
                                        var appointment = childSnapshot.val();
                                        if (appointment.status === "active") { // check status value
                                          var appointmentkey = childSnapshot.key; // extract appointment key
                                          // do something with appointmentkey

                                            firebase.database().ref("appointment/" + appointmentkey).once("value").then(function(snapshot) {
                                          
                                          var roname = snapshot.child("name").val();
                                          var roaddress = snapshot.child("address").val();
                                          var rophone = snapshot.child("phone").val();
                                          var roemail = snapshot.child("email").val();
                                          var roage = snapshot.child("age").val();
                                          var rogender = snapshot.child("gender").val();
                                          var roheight = snapshot.child("height").val();
                                          var roweight = snapshot.child("weight").val();
                                          var rocivilstatus = snapshot.child("civilstatus").val();
                                          var roparentname = snapshot.child("parentname").val();
                                          var romedicalcondition = snapshot.child("medicalcondition").val();
                                          var romedication = snapshot.child("medication").val();
                                          var roadditional = snapshot.child("additional").val();
                                          var rodate = snapshot.child("date").val();
                                          var rotime = snapshot.child("time").val();

                                          document.getElementById("name").value = roname;
                                          document.getElementById("address").value = roaddress;
                                          document.getElementById("phone").value = rophone;
                                          document.getElementById("email").value = roemail;
                                          document.getElementById("age").value = roage;
                                          document.getElementById("gender").value = rogender;
                                          document.getElementById("height").value = roheight;
                                          document.getElementById("weight").value = roweight;
                                          document.getElementById("civilstatus").value = rocivilstatus;
                                          document.getElementById("parentname").value = roparentname;
                                          document.getElementById("medicalcondition").value = romedicalcondition;
                                          document.getElementById("medication").value = romedication;
                                          document.getElementById("additional").value = roadditional;
                                          document.getElementById("date").value = rodate;
                                          document.getElementById("time").value = rotime;

                                          document.getElementById("name").readOnly = true;
                                          document.getElementById("address").readOnly = true;
                                          document.getElementById("phone").readOnly = true;
                                          document.getElementById("email").readOnly = true;
                                          document.getElementById("age").readOnly = true;
                                          document.getElementById("gender").disabled = true;
                                          document.getElementById("height").readOnly = true;
                                          document.getElementById("weight").readOnly = true;
                                          document.getElementById("civilstatus").disabled = true;
                                          document.getElementById("parentname").readOnly = true;
                                          document.getElementById("medicalcondition").disabled = true;
                                          document.getElementById("medication").disabled = true;
                                          document.getElementById("additional").readOnly = true;
                                          document.getElementById("date").readOnly = true;
                                          document.getElementById("time").readOnly = true;

                                          document.getElementById("setbutton").style.display = "none";
                                          document.getElementById("cancelbutton").style.display = "inline-block";
                                          document.getElementById("editbutton").style.display = "inline-block";
                                          selected = snapshot.child("medicalcondition").val();
                                          var dropdown = document.getElementById("medicalcondition");
                                          for (var i = 0; i < dropdown.options.length; i++) {
                                            if (selected.indexOf(dropdown.options[i].value) >= 0) {
                                              dropdown.options[i].selected = true;
                                            }
                                          }
                                          var document_style = document.documentElement.style;
                                          document_style.setProperty('--text', "'Selected: "+selected+"'");

                                          selectedmed = snapshot.child("medication").val();
                                          var dropdownmed = document.getElementById("medication");
                                          for (var i = 0; i < dropdownmed.options.length; i++) {
                                            if (selectedmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                              dropdownmed.options[i].selected = true;
                                            }
                                          }
                                          document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+selectedmed+"'");
                                                });
                                                } else if (appointment.status === "declined") {
                                                alert("Your booking has been declined!");
                                                document.getElementById("name").value = "";
                                                document.getElementById("address").value = "";
                                                document.getElementById("phone").value = "";
                                                document.getElementById("age").value = "";
                                                document.getElementById("gender").value = "Gender";
                                                document.getElementById("height").value = "";
                                                document.getElementById("weight").value = "";
                                                document.getElementById("civilstatus").value = "Civil Status";
                                                document.getElementById("parentname").value = "";
                                                document.getElementById("additional").value = "";
                                                document.getElementById("date").value = "";
                                                document.getElementById("time").value = "";

                                                var document_style = document.documentElement.style;
                                                document_style.setProperty('--text', "'Select past medical condition(s)'");
                                                document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Select medicine(s) taken(in the last 3 mos.)'");

                                                var dropdown = document.getElementById("medicalcondition");
                                                for (var i = 0; i < dropdown.options.length; i++) {
                                                  if (selected.indexOf(dropdown.options[i].value) >= 0) {
                                                    dropdown.options[i].selected = false;
                                                  }
                                                }

                                                var dropdownmed = document.getElementById("medication");
                                                for (var i = 0; i < dropdownmed.options.length; i++) {
                                                  if (selectedmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                                    dropdownmed.options[i].selected = false;
                                                  }
                                                }

                                                document.getElementById("name").readOnly = false;
                                                document.getElementById("address").readOnly = false;
                                                document.getElementById("phone").readOnly = false;
                                                document.getElementById("age").readOnly = false;
                                                document.getElementById("gender").disabled = false;
                                                document.getElementById("height").readOnly = false;
                                                document.getElementById("weight").readOnly = false;
                                                document.getElementById("civilstatus").disabled = false;
                                                document.getElementById("parentname").readOnly = false;
                                                document.getElementById("medicalcondition").disabled = false;
                                                document.getElementById("medication").disabled = false;
                                                document.getElementById("additional").readOnly = false;
                                                document.getElementById("date").readOnly = false;
                                                document.getElementById("time").readOnly = false;
                                                document.getElementById("updatebutton").style.display = "none";
                                                document.getElementById("editbutton").style.display = "none";
                                                document.getElementById("setbutton").style.display = "inline-block";
                                                document.getElementById("cancelbutton").style.display = "none";
                                                } else if (status === "done") {
                                                document.getElementById("name").value = "";
                                                document.getElementById("address").value = "";
                                                document.getElementById("phone").value = "";
                                                document.getElementById("age").value = "";
                                                document.getElementById("gender").value = "Gender";
                                                document.getElementById("height").value = "";
                                                document.getElementById("weight").value = "";
                                                document.getElementById("civilstatus").value = "Civil Status";
                                                document.getElementById("parentname").value = "";
                                                document.getElementById("additional").value = "";
                                                document.getElementById("date").value = "";
                                                document.getElementById("time").value = "";

                                                var document_style = document.documentElement.style;
                                                document_style.setProperty('--text', "'Select past medical condition(s)'");
                                                document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Select medicine(s) taken(in the last 3 mos.)'");

                                                var dropdown = document.getElementById("medicalcondition");
                                                for (var i = 0; i < dropdown.options.length; i++) {
                                                  if (selected.indexOf(dropdown.options[i].value) >= 0) {
                                                    dropdown.options[i].selected = false;
                                                  }
                                                }

                                                var dropdownmed = document.getElementById("medication");
                                                for (var i = 0; i < dropdownmed.options.length; i++) {
                                                  if (selectedmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                                    dropdownmed.options[i].selected = false;
                                                  }
                                                }

                                                document.getElementById("name").readOnly = false;
                                                document.getElementById("address").readOnly = false;
                                                document.getElementById("phone").readOnly = false;
                                                document.getElementById("age").readOnly = false;
                                                document.getElementById("gender").disabled = false;
                                                document.getElementById("height").readOnly = false;
                                                document.getElementById("weight").readOnly = false;
                                                document.getElementById("civilstatus").disabled = false;
                                                document.getElementById("parentname").readOnly = false;
                                                document.getElementById("medicalcondition").disabled = false;
                                                document.getElementById("medication").disabled = false;
                                                document.getElementById("additional").readOnly = false;
                                                document.getElementById("date").readOnly = false;
                                                document.getElementById("time").readOnly = false;
                                                document.getElementById("updatebutton").style.display = "none";
                                                document.getElementById("editbutton").style.display = "none";
                                                document.getElementById("setbutton").style.display = "inline-block";
                                                document.getElementById("cancelbutton").style.display = "none";
                                                }
                                            });
                                      });
                            }
          });
    });
  });
});

  var Updatebutton = document.getElementById("updatebutton");
Updatebutton.style.cursor = 'pointer';
Updatebutton.onmouseover = function() {
  Updatebutton.style.backgroundColor = '#38d55c';
}
Updatebutton.onmouseout = function() {
  Updatebutton.style.backgroundColor = '#28a745';
}

var Editbutton = document.getElementById("editbutton");
Editbutton.style.cursor = 'pointer';
Editbutton.onmouseover = function() {
  Editbutton.style.backgroundColor = '#38d55c';
}
Editbutton.onmouseout = function() {
  Editbutton.style.backgroundColor = '#28a745';
}

var Cancelbutton = document.getElementById("cancelbutton");
Cancelbutton.style.cursor = 'pointer';
Cancelbutton.onmouseover = function() {
  Cancelbutton.style.backgroundColor = '#db6772';
}
Cancelbutton.onmouseout = function() {
  Cancelbutton.style.backgroundColor = '#dc3545';
}
  document.getElementById("updatebutton").style.display = "none";
  document.getElementById("cancelbutton").style.display = "none";
  document.getElementById("editbutton").style.display = "none";


$(".multiple_select").mousedown(function(e) {
    if (e.target.tagName == "OPTION") 
    {
      return; //don't close dropdown if i select option
    }
    $(this).toggleClass('multiple_select_active'); //close dropdown if click inside <select> box
});
$(".multiple_select").on('blur', function(e) {
    $(this).removeClass('multiple_select_active'); //close dropdown if click outside <select>
});
  
$('.multiple_select option').mousedown(function(e) { //no ctrl to select multiple
    e.preventDefault(); 
    $(this).prop('selected', $(this).prop('selected') ? false : true); //set selected options on click
    $(this).parent().change(); //trigger change event
});
  var selected;
  $("#medicalcondition").on('change', function() {
      selected = $("#medicalcondition").val().toString().replaceAll(',', ', '); //here I get all options and convert to string
      var document_style = document.documentElement.style;
      if(selected !== "")
        document_style.setProperty('--text', "'Selected: "+selected+"'");
      else
        document_style.setProperty('--text', "'Select past medical condition(s)'");
  });

  if(selected !== ""){
      selected = $("#medicalcondition").val().toString().replaceAll(',', ', '); //here I get all options and convert to string
      var document_style = document.documentElement.style;
      if(selected !== ""){
        document_style.setProperty('--text', "'Selected: "+selected+"'");
      }
  }

  $(".multiple_selectmed").mousedown(function(e) {
    if (e.target.tagName == "OPTION") 
    {
      return; //don't close dropdown if i select option
    }
    $(this).toggleClass('multiple_select_activemed'); //close dropdown if click inside <select> box
});
$(".multiple_selectmed").on('blur', function(e) {
    $(this).removeClass('multiple_select_activemed'); //close dropdown if click outside <select>
});
  
$('.multiple_selectmed option').mousedown(function(e) { //no ctrl to select multiple
    e.preventDefault(); 
    $(this).prop('selected', $(this).prop('selected') ? false : true); //set selected options on click
    $(this).parent().change(); //trigger change event
});

  var selectedmed;
  $("#medication").on('change', function() {
      selectedmed = $("#medication").val().toString().replaceAll(',', ', '); //here I get all options and convert to string
      if(selectedmed !== "")
        document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+selectedmed+"'");
      else
        document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Select medicine(s) taken(in the last 3 mos.)'");
  });

  if(selectedmed !== ""){
      selectedmed = $("#medication").val().toString().replaceAll(',', ', '); //here I get all options and convert to string
      if(selectedmed !== ""){
        document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+selectedmed+"'");
      }
  }
var a, adate, atime, aname, Address, Phone, Email, Age, Gender, Height, Weight, Civilstatus, Parentname, Medicalcondition, Medication, Additional ;
function add_data(){
            var datenow = new Date();
            var yyyy = datenow.getFullYear();
            var mm = datenow.getMonth() + 1; // add 1 since getMonth() returns 0-11
            var dd = datenow.getDate();

            if (mm < 10) {
              mm = '0' + mm; // prepend 0 if month is less than 10
            }

            if (dd < 10) {
              dd = '0' + dd; // prepend 0 if date is less than 10
            }

            var Dateadded = yyyy + '/' + mm + '/' + dd;
            adate = document.getElementById("date").value;
            atime = document.getElementById("time").value;
            aname = document.getElementById("name").value;
            Address = document.getElementById("address").value;
            Phone = document.getElementById("phone").value;
            Email = document.getElementById("email").value;
            Age = document.getElementById("age").value;
            Gender = document.getElementById("gender").value;
            Height = document.getElementById("height").value;
            Weight = document.getElementById("weight").value;
            Civilstatus = document.getElementById("civilstatus").value;
            Parentname = document.getElementById("parentname").value;
            Medicalcondition = document.getElementById("medicalcondition").value;
            Medication = document.getElementById("medication").value;
            Additional = document.getElementById("additional").value;
            document.getElementById("setbutton").disabled = true;
            
            if(aname == "" || atime == "" || adate == "" || Address == "" || Age == "" || Gender == "Gender" || Civilstatus == "Civil Status" || Medicalcondition == "Select past medical condition(s)" || Medication == "Select medicine(s) taken(in the last 3 mos.)"){
            alert("Please fill all required information!");
            document.getElementById("setbutton").disabled = false;
            return;
            }

            firebase.database().ref().child("appointment").orderByChild("email").equalTo(newvalue).once("value",snap => {
                            if (snap.exists()){
                                     firebase.database().ref("appointment")
                                    .orderByChild("email")
                                    .equalTo(newvalue)
                                    .once("value")
                                    .then(function(snapshot) {
                                      snapshot.forEach(function(childSnapshot) {
                                        var appointment = childSnapshot.val();
                                        if (appointment.status === "declined") { // check status value
                                          var appointmentkey = childSnapshot.key; // extract appointment key
                                          
                                                    firebase.database().ref().child('appointment/'+ appointmentkey).set({
                                                    id: appointmentkey,
                                                    date: adate,
                                                    dateadded: Dateadded,
                                                    time: atime,
                                                    name: aname,
                                                    address: Address,
                                                    phone: Phone,
                                                    email: Email,
                                                    age: Age,
                                                    gender: Gender,
                                                    height: Height,
                                                    weight: Weight,
                                                    civilstatus: Civilstatus,
                                                    parentname: Parentname,
                                                    medicalcondition: selected,
                                                    medication: selectedmed,
                                                    status: "active",
                                                    additional: Additional
                                                    });


                                          alert("Added successfully!!!");
                                          document.getElementById("name").readOnly = true;
                                          document.getElementById("address").readOnly = true;
                                          document.getElementById("phone").readOnly = true;
                                          document.getElementById("email").readOnly = true;
                                          document.getElementById("age").readOnly = true;
                                          document.getElementById("gender").disabled = true;
                                          document.getElementById("height").readOnly = true;
                                          document.getElementById("weight").readOnly = true;
                                          document.getElementById("civilstatus").disabled = true;
                                          document.getElementById("parentname").readOnly = true;
                                          document.getElementById("medicalcondition").disabled = true;
                                          document.getElementById("medication").disabled = true;
                                          document.getElementById("additional").readOnly = true;
                                          document.getElementById("date").readOnly = true;
                                          document.getElementById("time").readOnly = true;

                                          document.getElementById("setbutton").style.display = "none";
                                          document.getElementById("cancelbutton").style.display = "inline-block";
                                          document.getElementById("editbutton").style.display = "inline-block";
                                          selected = snapshot.child("medicalcondition").val();
                                          var dropdown = document.getElementById("medicalcondition");
                                          for (var i = 0; i < dropdown.options.length; i++) {
                                            if (selected.indexOf(dropdown.options[i].value) >= 0) {
                                              dropdown.options[i].selected = true;
                                            }
                                          }
                                          var document_style = document.documentElement.style;
                                          document_style.setProperty('--text', "'Selected: "+selected+"'");

                                          selectedmed = snapshot.child("medication").val();
                                          var dropdownmed = document.getElementById("medication");
                                          for (var i = 0; i < dropdownmed.options.length; i++) {
                                            if (selectedmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                              dropdownmed.options[i].selected = true;
                                            }
                                          }
                                          document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+selectedmed+"'");

                                  }
                                                });
                               var pushedRef = firebase.database().ref().child('appointment/').push({
                                          date: adate,
                                          dateadded: Dateadded,
                                          time: atime,
                                          name: aname,
                                          address: Address,
                                          phone: Phone,
                                          email: Email,
                                          age: Age,
                                          gender: Gender,
                                          height: Height,
                                          weight: Weight,
                                          civilstatus: Civilstatus,
                                          parentname: Parentname,
                                          medicalcondition: selected,
                                          medication: selectedmed,
                                          status: "active",
                                          additional: Additional
                                        });

                                        a = pushedRef.key ;

                                        const dbRef = firebase.database().ref("appointment/" + a);
                                        dbRef.update({
                                          id: a
                                        });
                                        
                            firebase.database().ref("useraccounts").orderByChild("regnusername").equalTo(Loggedusername).once("value").then(function(snapshot) {
                              snapshot.forEach(function(childSnapshot) {
                                key = childSnapshot.key;
                                firebase.database().ref("useraccounts/" + key + "/regnemail").once("value").then(function(snapshot) {
                              var newvalue = snapshot.val(); 
                              document.getElementById("email").value = newvalue;
                              document.getElementById("email").readOnly = true;
                                      firebase.database().ref().child("appointment").orderByChild("email").equalTo(newvalue).once("value",snap => {
                                                        if (snap.exists()){
                                                          firebase.database().ref("appointment").orderByChild("email").equalTo(newvalue).once("value").then(function(snapshot) {
                                                                snapshot.forEach(function(childSnapshot) {
                                                                  appointmentkey = childSnapshot.key;
                                                                  firebase.database().ref("appointment/" + appointmentkey).once("value").then(function(snapshot) {
                                                                
                                                                var roname = snapshot.child("name").val();
                                                                var roaddress = snapshot.child("address").val();
                                                                var rophone = snapshot.child("phone").val();
                                                                var roemail = snapshot.child("email").val();
                                                                var roage = snapshot.child("age").val();
                                                                var rogender = snapshot.child("gender").val();
                                                                var roheight = snapshot.child("height").val();
                                                                var roweight = snapshot.child("weight").val();
                                                                var rocivilstatus = snapshot.child("civilstatus").val();
                                                                var roparentname = snapshot.child("parentname").val();
                                                                var romedicalcondition = snapshot.child("medicalcondition").val();
                                                                var romedication = snapshot.child("medication").val();
                                                                var roadditional = snapshot.child("additional").val();
                                                                var rodate = snapshot.child("date").val();
                                                                var rotime = snapshot.child("time").val();

                                                                document.getElementById("name").value = roname;
                                                                document.getElementById("address").value = roaddress;
                                                                document.getElementById("phone").value = rophone;
                                                                document.getElementById("email").value = roemail;
                                                                document.getElementById("age").value = roage;
                                                                document.getElementById("gender").value = rogender;
                                                                document.getElementById("height").value = roheight;
                                                                document.getElementById("weight").value = roweight;
                                                                document.getElementById("civilstatus").value = rocivilstatus;
                                                                document.getElementById("parentname").value = roparentname;
                                                                document.getElementById("medicalcondition").value = romedicalcondition;
                                                                document.getElementById("medication").value = romedication;
                                                                document.getElementById("additional").value = roadditional;
                                                                document.getElementById("date").value = rodate;
                                                                document.getElementById("time").value = rotime;

                                                                document.getElementById("name").readOnly = true;
                                                                document.getElementById("address").readOnly = true;
                                                                document.getElementById("phone").readOnly = true;
                                                                document.getElementById("email").readOnly = true;
                                                                document.getElementById("age").readOnly = true;
                                                                document.getElementById("gender").disabled = true;
                                                                document.getElementById("height").readOnly = true;
                                                                document.getElementById("weight").readOnly = true;
                                                                document.getElementById("civilstatus").disabled = true;
                                                                document.getElementById("parentname").readOnly = true;
                                                                document.getElementById("medicalcondition").disabled = true;
                                                                document.getElementById("medication").disabled = true;
                                                                document.getElementById("additional").readOnly = true;
                                                                document.getElementById("date").readOnly = true;
                                                                document.getElementById("time").readOnly = true;

                                                                document.getElementById("setbutton").style.display = "none";
                                                                document.getElementById("cancelbutton").style.display = "inline-block";
                                                                document.getElementById("editbutton").style.display = "inline-block";
                                                                var values = snapshot.child("medicalcondition").val();
                                                                var dropdown = document.getElementById("medicalcondition");
                                                                for (var i = 0; i < dropdown.options.length; i++) {
                                                                  if (values.indexOf(dropdown.options[i].value) >= 0) {
                                                                    dropdown.options[i].selected = true;
                                                                  }
                                                                }
                                                                var document_style = document.documentElement.style;
                                                                document_style.setProperty('--text', "'Selected: "+values+"'");

                                                                var valuesmed = snapshot.child("medication").val();
                                                                var dropdownmed = document.getElementById("medication");
                                                                for (var i = 0; i < dropdownmed.options.length; i++) {
                                                                  if (valuesmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                                                    dropdownmed.options[i].selected = true;
                                                                  }
                                                                }
                                                                document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+valuesmed+"'");
                                                                alert("Added successfully!!!");
                                                                document.getElementById("setbutton").disabled = true;
                                                                      });
                                                                    });
                                                                  });
                                                        }
                                      });
                                });
                              });
                            });
                            });
                            }else{
                              var pushedRef = firebase.database().ref().child('appointment/').push({
                                          date: adate,
                                          dateadded: Dateadded,
                                          time: atime,
                                          name: aname,
                                          address: Address,
                                          phone: Phone,
                                          email: Email,
                                          age: Age,
                                          gender: Gender,
                                          height: Height,
                                          weight: Weight,
                                          civilstatus: Civilstatus,
                                          parentname: Parentname,
                                          medicalcondition: selected,
                                          medication: selectedmed,
                                          status: "active",
                                          additional: Additional
                                        });

                                        a = pushedRef.key ;

                                        const dbRef = firebase.database().ref("appointment/" + a);
                                        dbRef.update({
                                          id: a
                                        });
                                        
                            firebase.database().ref("useraccounts").orderByChild("regnusername").equalTo(Loggedusername).once("value").then(function(snapshot) {
                              snapshot.forEach(function(childSnapshot) {
                                key = childSnapshot.key;
                                firebase.database().ref("useraccounts/" + key + "/regnemail").once("value").then(function(snapshot) {
                              var newvalue = snapshot.val(); 
                              document.getElementById("email").value = newvalue;
                              document.getElementById("email").readOnly = true;
                                      firebase.database().ref().child("appointment").orderByChild("email").equalTo(newvalue).once("value",snap => {
                                                        if (snap.exists()){
                                                          firebase.database().ref("appointment").orderByChild("email").equalTo(newvalue).once("value").then(function(snapshot) {
                                                                snapshot.forEach(function(childSnapshot) {
                                                                  appointmentkey = childSnapshot.key;
                                                                  firebase.database().ref("appointment/" + appointmentkey).once("value").then(function(snapshot) {
                                                                
                                                                var roname = snapshot.child("name").val();
                                                                var roaddress = snapshot.child("address").val();
                                                                var rophone = snapshot.child("phone").val();
                                                                var roemail = snapshot.child("email").val();
                                                                var roage = snapshot.child("age").val();
                                                                var rogender = snapshot.child("gender").val();
                                                                var roheight = snapshot.child("height").val();
                                                                var roweight = snapshot.child("weight").val();
                                                                var rocivilstatus = snapshot.child("civilstatus").val();
                                                                var roparentname = snapshot.child("parentname").val();
                                                                var romedicalcondition = snapshot.child("medicalcondition").val();
                                                                var romedication = snapshot.child("medication").val();
                                                                var roadditional = snapshot.child("additional").val();
                                                                var rodate = snapshot.child("date").val();
                                                                var rotime = snapshot.child("time").val();

                                                                document.getElementById("name").value = roname;
                                                                document.getElementById("address").value = roaddress;
                                                                document.getElementById("phone").value = rophone;
                                                                document.getElementById("email").value = roemail;
                                                                document.getElementById("age").value = roage;
                                                                document.getElementById("gender").value = rogender;
                                                                document.getElementById("height").value = roheight;
                                                                document.getElementById("weight").value = roweight;
                                                                document.getElementById("civilstatus").value = rocivilstatus;
                                                                document.getElementById("parentname").value = roparentname;
                                                                document.getElementById("medicalcondition").value = romedicalcondition;
                                                                document.getElementById("medication").value = romedication;
                                                                document.getElementById("additional").value = roadditional;
                                                                document.getElementById("date").value = rodate;
                                                                document.getElementById("time").value = rotime;

                                                                document.getElementById("name").readOnly = true;
                                                                document.getElementById("address").readOnly = true;
                                                                document.getElementById("phone").readOnly = true;
                                                                document.getElementById("email").readOnly = true;
                                                                document.getElementById("age").readOnly = true;
                                                                document.getElementById("gender").disabled = true;
                                                                document.getElementById("height").readOnly = true;
                                                                document.getElementById("weight").readOnly = true;
                                                                document.getElementById("civilstatus").disabled = true;
                                                                document.getElementById("parentname").readOnly = true;
                                                                document.getElementById("medicalcondition").disabled = true;
                                                                document.getElementById("medication").disabled = true;
                                                                document.getElementById("additional").readOnly = true;
                                                                document.getElementById("date").readOnly = true;
                                                                document.getElementById("time").readOnly = true;

                                                                document.getElementById("setbutton").style.display = "none";
                                                                document.getElementById("cancelbutton").style.display = "inline-block";
                                                                document.getElementById("editbutton").style.display = "inline-block";
                                                                var values = snapshot.child("medicalcondition").val();
                                                                var dropdown = document.getElementById("medicalcondition");
                                                                for (var i = 0; i < dropdown.options.length; i++) {
                                                                  if (values.indexOf(dropdown.options[i].value) >= 0) {
                                                                    dropdown.options[i].selected = true;
                                                                  }
                                                                }
                                                                var document_style = document.documentElement.style;
                                                                document_style.setProperty('--text', "'Selected: "+values+"'");

                                                                var valuesmed = snapshot.child("medication").val();
                                                                var dropdownmed = document.getElementById("medication");
                                                                for (var i = 0; i < dropdownmed.options.length; i++) {
                                                                  if (valuesmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                                                    dropdownmed.options[i].selected = true;
                                                                  }
                                                                }
                                                                document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+valuesmed+"'");
                                                                alert("Added successfully!!!");
                                                                document.getElementById("setbutton").disabled = true;
                                                                      });
                                                                    });
                                                                  });
                                                        }
                                      });
                                });
                              });
                            });
                            }
          });

           
}

function edit(){
              document.getElementById("name").readOnly = false;
              document.getElementById("address").readOnly = false;
              document.getElementById("phone").readOnly = false;
              document.getElementById("age").readOnly = false;
              document.getElementById("gender").disabled = false;
              document.getElementById("height").readOnly = false;
              document.getElementById("weight").readOnly = false;
              document.getElementById("civilstatus").disabled = false;
              document.getElementById("parentname").readOnly = false;
              document.getElementById("medicalcondition").disabled = false;
              document.getElementById("medication").disabled = false;
              document.getElementById("additional").readOnly = false;
              document.getElementById("date").readOnly = false;
              document.getElementById("time").readOnly = false;
              document.getElementById("updatebutton").style.display = "inline-block";
              document.getElementById("editbutton").style.display = "none";

}

function update(){
            var datenow = new Date();
            var yyyy = datenow.getFullYear();
            var mm = datenow.getMonth() + 1; // add 1 since getMonth() returns 0-11
            var dd = datenow.getDate();

            if (mm < 10) {
              mm = '0' + mm; // prepend 0 if month is less than 10
            }

            if (dd < 10) {
              dd = '0' + dd; // prepend 0 if date is less than 10
            }

            var Dateadded = yyyy + '/' + mm + '/' + dd;
            adate = document.getElementById("date").value;
            atime = document.getElementById("time").value;
            aname = document.getElementById("name").value;
            Address = document.getElementById("address").value;
            Phone = document.getElementById("phone").value;
            Email = document.getElementById("email").value;
            Age = document.getElementById("age").value;
            Gender = document.getElementById("gender").value;
            Height = document.getElementById("height").value;
            Weight = document.getElementById("weight").value;
            Civilstatus = document.getElementById("civilstatus").value;
            Parentname = document.getElementById("parentname").value;
            Medicalcondition = document.getElementById("medicalcondition").value;
            Medication = document.getElementById("medication").value;
            Additional = document.getElementById("additional").value;
            document.getElementById("updatebutton").disabled = true;
            
            if(aname == "" || atime == "" || adate == "" || Address == "" || Phone == "" || Email == "" || Age == "" || Gender == "Gender" || Civilstatus == "Civil Status" || Medicalcondition == "Select past medical condition(s)" || Medication == "Select medicine(s) taken(in the last 3 mos.)"){
            alert("Please fill all required information!");
            document.getElementById("updatebutton").disabled = false;
            return;
            }

firebase.database().ref("useraccounts").orderByChild("regnusername").equalTo(Loggedusername).once("value").then(function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    key = childSnapshot.key;

    firebase.database().ref("useraccounts/" + key + "/regnemail").once("value").then(function(snapshot) {
  var newvalue = snapshot.val(); 
  document.getElementById("email").value = newvalue;
  document.getElementById("email").readOnly = true;
          firebase.database().ref().child("appointment").orderByChild("email").equalTo(newvalue).once("value",snap => {
                            if (snap.exists()){
                               firebase.database().ref("appointment")
                                    .orderByChild("email")
                                    .equalTo(newvalue)
                                    .once("value")
                                    .then(function(snapshot) {
                                      snapshot.forEach(function(childSnapshot) {
                                        var appointment = childSnapshot.val();
                                        if (appointment.status === "active") { // check status value
                                          appointmentkey = childSnapshot.key; // extract appointment key
                                          // do something with appointmentkey

                                      firebase.database().ref().child('appointment/'+ appointmentkey).set({
                                          id: appointmentkey,
                                          date: adate,
                                          dateadded: Dateadded,
                                          time: atime,
                                          name: aname,
                                          address: Address,
                                          phone: Phone,
                                          email: Email,
                                          age: Age,
                                          gender: Gender,
                                          height: Height,
                                          weight: Weight,
                                          civilstatus: Civilstatus,
                                          parentname: Parentname,
                                          medicalcondition: selected,
                                          medication: selectedmed,
                                          status: "active",
                                          additional: Additional
                                        });
                                                                  
                                      firebase.database().ref("appointment/" + appointmentkey).once("value").then(function(snapshot) {
                                    
                                    var roname = snapshot.child("name").val();
                                    var roaddress = snapshot.child("address").val();
                                    var rophone = snapshot.child("phone").val();
                                    var roemail = snapshot.child("email").val();
                                    var roage = snapshot.child("age").val();
                                    var rogender = snapshot.child("gender").val();
                                    var roheight = snapshot.child("height").val();
                                    var roweight = snapshot.child("weight").val();
                                    var rocivilstatus = snapshot.child("civilstatus").val();
                                    var roparentname = snapshot.child("parentname").val();
                                    var romedicalcondition = snapshot.child("medicalcondition").val();
                                    var romedication = snapshot.child("medication").val();
                                    var roadditional = snapshot.child("additional").val();
                                    var rodate = snapshot.child("date").val();
                                    var rotime = snapshot.child("time").val();

                                    document.getElementById("name").value = roname;
                                    document.getElementById("address").value = roaddress;
                                    document.getElementById("phone").value = rophone;
                                    document.getElementById("email").value = roemail;
                                    document.getElementById("age").value = roage;
                                    document.getElementById("gender").value = rogender;
                                    document.getElementById("height").value = roheight;
                                    document.getElementById("weight").value = roweight;
                                    document.getElementById("civilstatus").value = rocivilstatus;
                                    document.getElementById("parentname").value = roparentname;
                                    document.getElementById("medicalcondition").value = romedicalcondition;
                                    document.getElementById("medication").value = romedication;
                                    document.getElementById("additional").value = roadditional;
                                    document.getElementById("date").value = rodate;
                                    document.getElementById("time").value = rotime;

                                    document.getElementById("name").readOnly = true;
                                    document.getElementById("address").readOnly = true;
                                    document.getElementById("phone").readOnly = true;
                                    document.getElementById("email").readOnly = true;
                                    document.getElementById("age").readOnly = true;
                                    document.getElementById("gender").disabled = true;
                                    document.getElementById("height").readOnly = true;
                                    document.getElementById("weight").readOnly = true;
                                    document.getElementById("civilstatus").disabled = true;
                                    document.getElementById("parentname").readOnly = true;
                                    document.getElementById("medicalcondition").disabled = true;
                                    document.getElementById("medication").disabled = true;
                                    document.getElementById("additional").readOnly = true;
                                    document.getElementById("date").readOnly = true;
                                    document.getElementById("time").readOnly = true;

                                    document.getElementById("setbutton").style.display = "none";
                                    document.getElementById("cancelbutton").style.display = "inline-block";
                                    document.getElementById("editbutton").style.display = "inline-block";
                                    document.getElementById("updatebutton").style.display = "none";
                                    var values = snapshot.child("medicalcondition").val();
                                    var dropdown = document.getElementById("medicalcondition");
                                    for (var i = 0; i < dropdown.options.length; i++) {
                                      if (values.indexOf(dropdown.options[i].value) >= 0) {
                                        dropdown.options[i].selected = true;
                                      }
                                    }
                                    var document_style = document.documentElement.style;
                                    document_style.setProperty('--text', "'Selected: "+values+"'");

                                    var valuesmed = snapshot.child("medication").val();
                                    var dropdownmed = document.getElementById("medication");
                                    for (var i = 0; i < dropdownmed.options.length; i++) {
                                      if (valuesmed.indexOf(dropdownmed.options[i].value) >= 0) {
                                        dropdownmed.options[i].selected = true;
                                      }
                                    }
                                    document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Selected: "+valuesmed+"'");
                                    alert("Updated successfully!!!");
                                    document.getElementById("updatebutton").disabled = false;
                                          });
                                          }
                                        });
                                      });
                            }
          });
    });
  });
});
            }

function cancel(){
            document.getElementById("cancelbutton").disabled = true;
            firebase.database().ref("appointment")
            .orderByChild("email")
            .equalTo(newvalue)
            .once("value")
            .then(function(snapshot) {
              snapshot.forEach(function(childSnapshot) {
                var appointment = childSnapshot.val();
                if (appointment.status === "active") { // check status value
                  appointmentkey = childSnapshot.key; // extract appointment key
                  // do something with appointmentkey
              const dbRef = firebase.database().ref("appointment/" + appointmentkey);
            dbRef.remove()
              .then(() => {
              document.getElementById("name").value = "";
              document.getElementById("address").value = "";
              document.getElementById("phone").value = "";
              document.getElementById("age").value = "";
              document.getElementById("gender").value = "Gender";
              document.getElementById("height").value = "";
              document.getElementById("weight").value = "";
              document.getElementById("civilstatus").value = "Civil Status";
              document.getElementById("parentname").value = "";
              document.getElementById("additional").value = "";
              document.getElementById("date").value = "";
              document.getElementById("time").value = "";

              var document_style = document.documentElement.style;
              document_style.setProperty('--text', "'Select past medical condition(s)'");
              document.querySelector('.multiple_selectmed').style.setProperty('--text', "'Select medicine(s) taken(in the last 3 mos.)'");

              var dropdown = document.getElementById("medicalcondition");
              for (var i = 0; i < dropdown.options.length; i++) {
                if (selected.indexOf(dropdown.options[i].value) >= 0) {
                  dropdown.options[i].selected = false;
                }
              }

              var dropdownmed = document.getElementById("medication");
              for (var i = 0; i < dropdownmed.options.length; i++) {
                if (selectedmed.indexOf(dropdownmed.options[i].value) >= 0) {
                  dropdownmed.options[i].selected = false;
                }
              }

              document.getElementById("name").readOnly = false;
              document.getElementById("address").readOnly = false;
              document.getElementById("phone").readOnly = false;
              document.getElementById("age").readOnly = false;
              document.getElementById("gender").disabled = false;
              document.getElementById("height").readOnly = false;
              document.getElementById("weight").readOnly = false;
              document.getElementById("civilstatus").disabled = false;
              document.getElementById("parentname").readOnly = false;
              document.getElementById("medicalcondition").disabled = false;
              document.getElementById("medication").disabled = false;
              document.getElementById("additional").readOnly = false;
              document.getElementById("date").readOnly = false;
              document.getElementById("time").readOnly = false;
              document.getElementById("updatebutton").style.display = "none";
              document.getElementById("editbutton").style.display = "none";
              document.getElementById("setbutton").style.display = "inline-block";
              document.getElementById("cancelbutton").style.display = "none";
              document.getElementById("cancelbutton").disabled = false;
              alert("Appointment cancelled successfully!!!");
              })
              .catch((error) => {
                alert("Appointment cancellation failed: ", error);
              });
        }
      });
    });
    }

    function log_out(){
      localStorage.removeItem("loggedusername"); //For log out
      if(Loggedusername == null){
        window.location.replace("userlogin.php");
      }else{
        window.location.replace("userlogin.php");
      }
    }
</script>

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title">
          <h2>News & Events</h2>
          <p>Check out the latest news and our RHU medical activities</p>
        </div>

        <div class="row portfolio-container">
        </div>

        <div id="newsevents" class="row portfolio-container">
        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <script>
    firebase.database().ref().child('newsandevents').on("child_added", snap =>{
    var Id = snap.child("id").val();
    var Article = snap.child("article").val();
    var Picture = snap.child("picture").val();
    var Title = snap.child("title").val();
    var Author = snap.child("author").val();
    var Datepublished = snap.child("date").val();

    var div1 = "col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp";
    var div2 = "portfolio-wrap";
    var div3 = "portfolio-info";
    var imgclass ="img-fluid";
    var aclass = "link-preview portfolio-lightbox";
    var adatagal ="portfolioGallery";
    var atitle ="Preview";
    var ahref ="portfolio-details.php";
    var iclass = "bx bx-plus";
    var aclass2 = "link-details";
    var atitle2 ="More Details";
    var iclass2 = "bx bx-link";
    var Image = "Image";
    var myimage = "myImg";

    var html = `
    <div class="${div1}">
        <div class="${div2}">
            <figure>
                <img id="${myimage}" class="${imgclass}" src="${Picture}" alt="${Image}">
                <a href="${Picture}" data-gallery="${adatagal}" class="${aclass}" title="${atitle}">
                    <i class="${iclass}"></i>
                </a>
                <a href="${ahref}" id="${Id}" onclick="localStorage.setItem('toviewcontent', this.id);" class="${aclass2}" title="${atitle2}">
                    <i class="${iclass2}"></i>
                </a>
            </figure>
            <div class="${div3}">
                <h4><a id="${Id}" onclick="localStorage.setItem('toviewcontent', this.id);" href="${ahref}">${Title}</a></h4>
                <p>Date published: ${Datepublished}</p>
                <p>Published by: ${Author}</p>
            </div>
        </div>
    </div>
`;

$("#newsevents").prepend(html);
    });
    </script>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Contact Us</h2>
          <p>Reach us through this following contacts</p>
        </div>

        <div class="row mt-5 justify-content-center">

          <div class="col-lg-10">

            <div class="info-wrap">
              <div class="row">
                <div class="col-lg-4 info">
                  <i class="bi bi-geo-alt"></i>
                  <h4>Location:</h4>
                  <p>Poblacion Centro<br>Buenavista, Bohol</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-envelope"></i>
                  <h4>Email:</h4>
                  <p>info@example.com<br>contact@example.com</p>
                </div>

                <div class="col-lg-4 info mt-4 mt-lg-0">
                  <i class="bi bi-phone"></i>
                  <h4>Call:</h4>
                  <p>+1 5589 55488 51<br>+1 5589 22475 14</p>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">
          
    <div class="container d-md-flex py-4">
      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>MRS</span></strong>. All Rights Reserved
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>