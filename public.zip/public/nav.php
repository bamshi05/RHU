<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="admin.php">
                    <img src="images/icon/rhulogo.jpg" alt="RHU BUENAVISTA" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a class="js-arrow" href="chart.php"><i class="fas fa-chart-bar"></i>Dashboard</a>
                        </li>
                        <li class="has-sub">
                            <a href="admin.php"><i class="far fa-check-square"></i>Appointments</a>
                        </li>
                        <li>
                            <a class="js-arrow" href="news.php"><i class="fas fa-copy"></i>News & Events</a>
                        </li>
                        <li>
                            <a class="js-arrow" href="contact.php"><i class="fas">[#]</i>Contacts</a>
                        </li>
                        <li>
                            <a class="js-arrow" href="aboutus.php"><i class="fas fa-map-marker-alt"></i>About Us</a>
                        </li>
                        <li class="has-sub">
                                <a class="js-arrow" href="#"><i class="fas fa-table"></i>Users Data</a>
                                <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                  <li>
                                    <a href="table3.php">Patient Records</a>
                                  </li>
                                  <li>
                                    <a href="table.php">Accounts</a>
                                  </li>
                                </ul>
                              </li>
                    </ul>
                </nav>
            </div>
        </aside>
