<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MRSUSER</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<style type="text/css">
#hero {
  width: 100%;
  height: 60vh;
  background: url("assets/img/rhu11.jpg") center center;
  background-size: cover;
  position: relative;
  margin-top: 70px;
  padding: 0;
}
</style>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="index.php#hero">RHU Buenavista</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
    </div>
    <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto" href="index.php#login">Log-in</a></li>
          <li><a class="nav-link scrollto " href="index.php#signup">Sign-up</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="container text-center text-md-left" data-aos="fade-up">
      <h1>Welcome to <span>Buenavista RHU Medical Record System</span></h1>
      <h2>Book your doctors appointment now!!!</h2>
      <a href="#login" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Sign-In Section ======= -->
    <section id="login" class="services section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Sign-In</h2>
          <p>Enter your registered account</p>
        <!-- ======= Sign-In Form Section ======= -->
    <section class="contact section-bg">
      <div class="container">
        <div class="row mt-5 justify-content-center">
          <div style="width: 500px" class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <input type="text" class="form-control" name="username" id="username" placeholder="Username" required>
              <div class="my-3">
                <div></div>
              </div>
              <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
              <div class="my-3">
                <div></div>
                <div></div>
                <div></div>
              </div>
              <div class="text-center"><button type="submit" onclick="login()">Log-in</button></div>
              <nav id="navbar" class="navbar order-last order-lg-0 justify-content-center">
          <a class="nav-link scrollto" style="margin-left: -20px" href="#signup">Register Account</a>
      </nav><!-- .navbar -->
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Sign-In Form Section -->
    </div>
      </div>
    </section><!-- End Sign-In Section -->

    <!-- ======= Sign-Up Section ======= -->
    <section id="signup" class="services section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Sign-Up</h2>
          <p>Enter your personal information to register</p>
        <!-- ======= Appointment Form Section ======= -->
    <section class="contact section-bg">
      <div class="container">
        <div class="row mt-5 justify-content-center">
          <div class="col-lg-10">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form signupform">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="firstname" class="form-control" id="firstname" placeholder="First Name" required>
                </div>
                <div class="col-md-6 form-group">
                  <input type="text" name="lastname" class="form-control" id="lastname" placeholder="Last Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="regnemail" id="regnemail" placeholder="Email" required>
                </div>
                <div class="col-md-6 form-group">
                  <input type="text" name="regnusername" class="form-control" id="regnusername" placeholder="Username" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="password" class="form-control" name="regnpassword" id="regnpassword" placeholder="Password" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="password" class="form-control" name="confirmpass" id="confirmpass" placeholder="Confirm Password" required>
                </div>
              </div>
              <div class="my-3">
                <div></div>
                <div></div>
                <div></div>
              </div>
              <a class="nav-link scrollto" >By checking the box below, you confirm that you have read, understood, and agree to abide by these</a>
              <div style="display: flex; align-items: center; justify-content: center;">
                <input type="checkbox" id="policycheckbox" required>
                <a href="policy.php" style="margin-left: 5px;">Terms & Conditions</a>
              </div>
              <div class="text-center"><button type="submit" id="submit" onclick="signup()">Create Account</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Sign-Up Form Section -->
    </div>
      </div>
    </section><!-- End Sign-Up Section -->


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->

<script>
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAcA8u0hL4KKhGjDRJEnEm1jhHUAfcTsaE",
    authDomain: "tsisdb.firebaseapp.com",
    databaseURL: "https://tsisdb.firebaseio.com",
    projectId: "tsisdb",
    storageBucket: "tsisdb.appspot.com",
    messagingSenderId: "117101059158",
    appId: "1:117101059158:web:0676e4596c5ed5dcfd2ff7"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
</script>

<script>
  function login(){
            var Username = document.getElementById("username").value;
            var Password = document.getElementById("password").value;
            localStorage.setItem("loggedusername", Username);
            
            if(Username == "" || Password  == ""){
            alert("Please fill all required information!");
            return;
            }else{
            firebase.database().ref().child("useraccounts").orderByChild("regnusername").equalTo(Username).once("value",snapshot => {
                  if (snapshot.exists()){
                              firebase.database().ref().child("useraccounts").orderByChild("confirmpass").equalTo(Password).once("value",snap => {
                            if (snap.exists()){
                              window.location.replace("home.php");
                            }else{
                              alert("Account don't exist, please try again!");
                              var frm = document.getElementsByClassName('php-email-form')[0];
                              frm.reset();
                            }
                            });
                  }else{
                    alert("Username not registered, please try again!");
                    var frm = document.getElementsByClassName('php-email-form')[0];
                    frm.reset();
                  }
              });
            }
  } 

function signup(){

            var Firstname = document.getElementById("firstname").value;
            var Lastname = document.getElementById("lastname").value;
            var Regnmail = document.getElementById("regnemail").value;
            var Regnusername = document.getElementById("regnusername").value;
            var Regnpassword = document.getElementById("regnpassword").value;
            var Confirmpass = document.getElementById("confirmpass").value;
            var emailRegex = /^[-!#$%&'*+\/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+\/0-9=?A-Z^_a-z`{|}~])*@[a-zA-Z0-9](-*\.?[a-zA-Z0-9])*\.[a-zA-Z](-?[a-zA-Z0-9])+$/;

            const Policycheckbox = document.getElementById("policycheckbox");

            if(Firstname == "" || Lastname == "" || Regnmail == "" || Regnusername == "" || Regnpassword == "" || Confirmpass == ""){
            alert("Please fill all required information!");
            return;
            }else if (!Policycheckbox.checked) {
              alert("Agree to the Terms and Agreement to continue!");
            return;
            }
                if (!Regnmail){
                    alert("Email not valid!");
                    return;
                }else if(Regnmail.length>254){
                    alert("Email not valid!");
                    return;
                }

                var valid = emailRegex.test(Regnmail);
                if(!valid){
                  alert("Email not valid!");
                    return;
                }
                 // Further checking of some things regex can't handle
                var parts = Regnmail.split("@");
                if(parts[0].length>64){
                  alert("Email not valid!");
                    return;
                }
                var domainParts = parts[1].split(".");
                if(domainParts.some(function(part) { return part.length>63; })){
                  alert("Email not valid!");
                    return;
                } 
                firebase.database().ref().child("useraccounts").orderByChild("regnemail").equalTo(Regnmail).once("value",snap => {
                      if (snap.exists()){
                          alert("Email already used!");
                          return;
                      }else{
                          firebase.database().ref().child("useraccounts").orderByChild("regnusername").equalTo(Regnusername).once("value",snap => {
                                if (snap.exists()){
                                    alert("Username already used!");
                                    return;
                                }else if (Regnpassword == Confirmpass) {

                                var pushedRef = firebase.database().ref().child('useraccounts/').push({
                                  firstname: Firstname,
                                  lastname: Lastname,
                                  regnemail: Regnmail,
                                  regnusername: Regnusername,
                                  confirmpass: Confirmpass
                                });

                                var a = pushedRef.key ;

                                firebase.database().ref().child('useraccounts/'+ a).set({
                                  id: a,
                                  firstname: Firstname,
                                  lastname: Lastname, 
                                  regnemail: Regnmail,
                                  regnusername: Regnusername,
                                  confirmpass: Confirmpass
                                });
                                  
                                 firebase.database().ref().child("useraccounts").orderByChild("regnusername").equalTo(Regnusername).once("value",snap => {
                                if (snap.exists()){
                                    alert("Account sucessfully registered!");
                                   var frm = document.getElementsByClassName('signupform')[0];
                                   frm.reset();
                                   var login = document.getElementsByClassName('nav-link')[0];
                                   login.click();
                                }else{
                                   alert("Account registration failed, please try again!");
                                    return;
                                } 
                                });
                                }else{
                                  alert("Password did not match!");
                                  return;
                                }  
                          });
                      }
                });
          } 
</script>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Contact Us</h2>
          <p>Reach us through this following contacts</p>
        </div>
        
        <div id="contactbanner" class="row mt-5 justify-content-center">
        </div>

      </div>
    </section><!-- End Contact Section -->
<script>
    firebase.database().ref().child('contacts').on("child_added", snap =>{
    var Id = snap.child("id").val();
    var Address = snap.child("address").val();
    var Email = snap.child("email").val();
    var Contact = snap.child("contactnumber").val();

    var div1 = "col-lg-10";
    var div2 = "info-wrap";
    var div3 = "row";
    var div4 = "col-lg-4 info";
    var iclass ="bi bi-geo-alt";
    var div5 = "col-lg-4 info mt-4 mt-lg-0";
    var iclass2 ="bi bi-envelope";
    var div6 = "col-lg-4 info mt-4 mt-lg-0";
    var iclass3 ="bi bi-phone";

    var contactdisplay = `
    <div class="${div1}">

            <div class="${div2}">
              <div class="${div3}">
                <div class="${div4}">
                  <i class="${iclass}"></i>
                  <h4>Location:</h4>
                  <p>${Address}</p>
                </div>

                <div class="${div5}">
                  <i class="${iclass2}"></i>
                  <h4>Email:</h4>
                  <p>${Email}</p>
                </div>

                <div class="${div6}">
                  <i class="${iclass3}"></i>
                  <h4>Call:</h4>
                  <p>${Contact}</p>
                </div>
              </div>
            </div>

          </div>
`;

$("#contactbanner").append(contactdisplay);
    });
    </script>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">
          
    <div class="container d-md-flex py-4">
      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>RHU Buenavista</span></strong>. All Rights Reserved
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>