<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MRS WEB</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Lumia - v4.10.0
  * Template URL: https://bootstrapmade.com/lumia-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<style type="text/css">
#hero {
  width: 100%;
  height: 60vh;
  background: url("assets/img/rhu11.jpg") center center;
  background-size: cover;
  position: relative;
  margin-top: 70px;
  padding: 0;
}
</style>


<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <h1><a href="home.php#hero">RHU Buenavista</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
           <li><a class="nav-link scrollto active" href="home.php#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="home.php#about">About</a></li>
          <li><a class="nav-link scrollto" href="home.php#services">Appointment Form</a></li>
          <li><a class="nav-link scrollto " href="home.php#portfolio">News & Events</a></li>
          <li><a class="nav-link scrollto" href="home.php#contact">Contact</a></li>
          <li class="dropdown"><a href="#"><span>Account Options</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="" onclick="log_out()">Sign-out</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Article Details</h2>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
      <div class="container">

        <div id="viewcontent" class="row gy-4">
        </div>

      </div>
    </section><!-- End Portfolio Details Section -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.2.0/firebase.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->

<script>
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAcA8u0hL4KKhGjDRJEnEm1jhHUAfcTsaE",
    authDomain: "tsisdb.firebaseapp.com",
    databaseURL: "https://tsisdb.firebaseio.com",
    projectId: "tsisdb",
    storageBucket: "tsisdb.appspot.com",
    messagingSenderId: "117101059158",
    appId: "1:117101059158:web:0676e4596c5ed5dcfd2ff7"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
</script>
    <script>
     var Loggedusername = localStorage.getItem("loggedusername");

  if (Loggedusername === null || Loggedusername === undefined) {
   window.location.replace("index.php");
  }
    var idsaved = localStorage.getItem("toviewcontent");
    firebase.database().ref("newsandevents/" + idsaved).once("value").then(function(snapshot) {
    var Id = snapshot.child("id").val();
    var Article = snapshot.child("article").val();
    var Picture = snapshot.child("picture").val();
    var Title = snapshot.child("title").val();
    var Author = snapshot.child("author").val();
    var When = snapshot.child("when").val();
    var Where = snapshot.child("where").val();
    var Datepublished = snapshot.child("date").val();

    var div1 = "col-lg-8";
    var div2 = "portfolio-details-slider swiper";
    var div3 = "swiper-wrapper align-items-center";
    var div4 = "swiper-pagination";
    var div5 = "col-lg-4";
    var div6 = "portfolio-info";
    var div7 = "portfolio-description";
    var Image = "Image";

    var html = `
    <div class="${div1}">
            <div class="${div2}">
              <div class="${div3}">

                <div>
                  <img src="${Picture}" alt="${Image}">
                </div>

              </div>
              <div class="${div4}"></div>
            </div>
          </div>

          <div class="${div5}">
            <div class="${div6}">
              <h3>Article Information</h3>
              <ul>
                <li><strong>Author</strong>: ${Author}</li>
                <li><strong>Date Published</strong>: ${Datepublished}</li>
              </ul>
            </div>
            <div class="${div7}">
              <div class="${div6}">
              <h3>Event Information</h3>
              <ul>
                <li><strong>What</strong>: ${Title}</li>
                <li><strong>When</strong>: ${When}</li>
                <li><strong>Where</strong>: ${Where}</li>
              </ul>
            </div>
            </div>
          </div>
          <h2>${Title}</h2>
              <p>
                ${Article}
              </p>
`;

$("#viewcontent").append(html);

    });
function log_out(){
      localStorage.removeItem("loggedusername"); //For log out
      if (Loggedusername === null || Loggedusername === undefined) {
       window.location.replace("index.php");
        }
      }
    </script>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>RHU Buenavista</span></strong>. All Rights Reserved
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>