module.exports = function ones(size) {
  return new Float32Array(size).fill(1);
}
